package com.example.dementiaDetectorApp.models

data class Address(var lineOne: String,
                   var lineTwo: String?=null,
                   var lineThree: String?=null,
                   var city: String,
                   var county: String,
                   var eircode: String){}