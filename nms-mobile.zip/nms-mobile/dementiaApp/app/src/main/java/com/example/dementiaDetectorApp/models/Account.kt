package com.example.dementiaDetectorApp.models

data class Account (val accountID: String,
                    var email: String,
                    var password: String,
                    var fName: String,
                    var lName:String,
                    var phoneNum: String,
                    var address: Address){}