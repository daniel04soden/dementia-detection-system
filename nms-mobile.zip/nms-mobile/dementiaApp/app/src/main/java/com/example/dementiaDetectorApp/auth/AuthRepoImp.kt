package com.example.dementiaDetectorApp.auth

import android.content.SharedPreferences
import retrofit2.HttpException

class AuthRepoImp(
    private val api:AuthAPI,
    private val prefs: SharedPreferences
):AuthRepository{

    override suspend fun signUp(username: String, pswd: String): AuthResult<Unit> {
       return try{
           api.signUp(
               request = AuthRequest(
                   email = username,
                   pswd = pswd
               )
           )
           signIn(username, pswd)
       }catch (e: HttpException){
           if(e.code()==401){
               AuthResult.Unauthorized()
           }else{
               AuthResult.UnknownError()
           }
       }catch(e: Exception){
            AuthResult.UnknownError()
       }
    }

    override suspend fun signIn(username: String, pswd: String): AuthResult<Unit> {
        return try{
            val response = api.signIn(
                request = AuthRequest(
                    email=username,
                    pswd=pswd
                )
            )
            prefs.edit()
                .putString("jwt", response.token)
                .apply()
            AuthResult.Authorized()

        }catch (e: HttpException){
            if(e.code()==401){
                AuthResult.Unauthorized()
            }else{
                AuthResult.UnknownError()
            }
        }catch(e: Exception){
            AuthResult.UnknownError()
        }
    }

    override suspend fun authenticate(): AuthResult<Unit> {
        return try{
            val token = prefs.getString("jwt", null)?: return AuthResult.Unauthorized()
            api.authenticate("Bearer $token")
            AuthResult.Authorized()

        }catch (e: HttpException){
            if(e.code()==401){
                AuthResult.Unauthorized()
            }else{
                AuthResult.UnknownError()
            }
        }catch(e: Exception) {
            AuthResult.UnknownError()
        }
    }
}