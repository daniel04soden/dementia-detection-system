package com.example.dementiaDetectorApp.auth

data class AuthRequest(
    val email: String,
    val pswd: String
)
