package com.example.dementiaDetectorApp.di
import android.app.Application
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import com.example.dementiaDetectorApp.auth.AuthAPI
import com.example.dementiaDetectorApp.auth.AuthRepoImp
import com.example.dementiaDetectorApp.auth.AuthRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.create
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provAuthAPI(): AuthAPI{
        return Retrofit.Builder()
            .baseUrl("http://192.168.1.10:8080/")
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create()
    }

    @Provides
    @Singleton
    fun provSharedPref(app: Application): SharedPreferences{
        return app.getSharedPreferences("prefs", MODE_PRIVATE)
    }

    @Provides
    @Singleton
    fun provAuthRepo(api: AuthAPI, prefs: SharedPreferences): AuthRepository{
        return AuthRepoImp(api, prefs)
    }
}