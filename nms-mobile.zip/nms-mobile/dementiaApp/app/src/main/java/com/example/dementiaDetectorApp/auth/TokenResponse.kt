package com.example.dementiaDetectorApp.auth

data class TokenResponse(
    val token: String
)
